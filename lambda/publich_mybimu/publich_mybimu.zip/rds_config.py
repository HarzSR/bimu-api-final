#config file containing credentials for RDS MySQL instance
db_username = "user"
db_password = "!1Password"
db_name = "mybimu"
